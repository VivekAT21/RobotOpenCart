def write_xls_file(file_name, text):
    f = open(file_name, "a")
    f.write("\n" + text)
    f.close()


item = ["vivek", "garg"]
for l in item:
    write_xls_file("D://projects//automationworkspace//OpenCart//TestData//demo.txt", l)