import selenium
from selenium import webdriver
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager


def initiate_browser(browser_name):
    if browser_name == browser_name:
        driver = webdriver.Chrome(ChromeDriverManager().install())
    elif browser_name == browser_name:
        driver = webdriver.Firefox(executable_path=GeckoDriverManager().install())
    return driver

