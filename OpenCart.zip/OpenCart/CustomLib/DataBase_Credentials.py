
def database_creds(env):
    ListOfTestEnv = ['staging', 'staging2', 'qa', 'qa2', 'wsstaging', 'wsstaging2','wsqa', 'wsqa2']
    if env in ListOfTestEnv:
        hostname = 'qa-dbha'
        database = 'TIPSTest'
    elif env == 'int':
        hostname = 'int-DBHA'
        database = 'TIPSInt'
    elif env == 'dev':
        hostname = 'dev-DBHA'
        database = 'TIPSDev'
    elif env == 'production' or env == 'prodtest' or env == 'failover':
        hostname = 'prod-DBHA'
        database = 'TIPS'
    # This is the hostname for the AWS instance of TIPS DB.
    return database,hostname
