
class config_constants:
    BASE_URL = "https://demo.opencart.com/admin"
    WAIT_DURATION = 10


