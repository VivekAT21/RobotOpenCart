import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.wait import WebDriverWait
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.support import expected_conditions as EC
from HybridPythonFW.pages.BasePage import BasePage

web_driver = webdriver.Chrome(ChromeDriverManager().install())
# request.class.driver
# means driver is available to the requesting class
web_driver.maximize_window()
web_driver.get("https://www.jqueryscript.net/demo/Drop-Down-Combo-Tree/")
web_driver.execute_script()
web_driver.find_element()
"arguments[0].scrollIntoView();", by_locator

# by_locator = (By.ID, "dropdown-class-example")
# # bb = BasePage(web_driver)
# # bb.select_dropdown_by_value(xx, 'option3')
#
# # by_locator = (By.XPATH, "//select[@id='dropdown-class-example']")
# web_element = WebDriverWait(web_driver, 10).until(EC.visibility_of_element_located(by_locator))
# select = Select(web_element)
# option_list = select.options
# for ele in option_list:
#     if ele.text == 'Option3':
#         ele.click()
#         break
#
# print("vivek")
by_locator = (By.XPATH, "//div[@class='col-lg-6'][1]//span")
# option_list = web_driver.find_elements(By.XPATH, "//div[@class='col-lg-6'][1]//span")
option_list = web_driver.find_elements(By.CSS_SELECTOR, 'span.comboTreeItemTitle')
# option_list = WebDriverWait(web_driver, 10).until(EC.visibility_of_all_elements_located(by_locator))
# print(option_list)
value_list = ['choice 1', 'choice 2']
# def select_dropdown_values(option_list, value_list):

if not value_list[0] == 'all':
    for ele in option_list:
        print(ele.text)
        for k in range(len(value_list)):
            if ele.text == value_list[k]:
                ele.click()
                break
else:
    try:
        for ele in option_list:
            print(ele.text)
            ele.click()
    except Exception as e:
        print(e)

print("vivek")