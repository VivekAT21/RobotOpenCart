demo_dict = {"lan": "java", "lan2": "pyton"}
print(demo_dict["lan"])
demo_dict["prd"] = "URL"
print(demo_dict)

while True:

    try:
        x = int(input("enter Name"))
        print(x)
        break
    except Exception as e:
        print("Incorrect code")
    finally:
        print("xx")