# class TestData:
ADMIN_LOGIN_PAGE_TITLE = "Administration"
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "admin"
ADMIN_DASHBOARD_HEADING = "Dashboard"

ADMIN_ORDER_TITLE = "Orders"

# ADD PRODUCTS CONSTANTS
PRODUCT_NAME = "Product_001"
PRODUCT_META_TAG = "Product_Meta_tag_001"

